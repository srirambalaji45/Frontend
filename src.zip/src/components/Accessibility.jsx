import { PersonStanding } from "lucide-react"
import './accessibility.scss'


function Accessibility(){
    return(
        <button className="accessibility-btn"><PersonStanding /></button>
    )
}

export default Accessibility
